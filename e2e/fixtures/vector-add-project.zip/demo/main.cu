#include <cstdio>
#include "include/kernels.cuh"

int main() {
  const int n = 1 << 20;
  float *a, *b, *c;
  cudaMallocManaged(&a, n * sizeof(float));
  cudaMallocManaged(&b, n * sizeof(float));
  cudaMallocManaged(&c, n * sizeof(float));
  for (int i = 0; i < n; i++) { a[i] = 1.0f; b[i] = 2.0f; }

  launchVectorAdd(a, b, c, n);
  cudaDeviceSynchronize();

  printf("c[0] = %.1f (expected 3.0)\n", c[0]);
  cudaFree(a); cudaFree(b); cudaFree(c);
  return 0;
}
