#pragma once

/** Adds two vectors on the GPU: c = a + b. */
void launchVectorAdd(const float *a, const float *b, float *c, int n);
