#include "../include/kernels.cuh"

__global__ void vectorAdd(const float *a, const float *b, float *c, int n) {
  int i = blockIdx.x * blockDim.x + threadIdx.x;
  if (i < n) c[i] = a[i] + b[i];
}

void launchVectorAdd(const float *a, const float *b, float *c, int n) {
  vectorAdd<<<(n + 255) / 256, 256>>>(a, b, c, n);
}
